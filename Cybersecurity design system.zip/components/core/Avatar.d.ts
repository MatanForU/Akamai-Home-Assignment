export interface AvatarProps {
  name?: string;
  size?: "sm" | "md" | "lg";
  src?: string;
}
